package com.coffeeshop.behavioral.strategy;

/**
 * Concrete strategy that processes payment with physical cash.
 * <p>
 * Simply logs the amount tendered. No card or digital wallet involved.
 */
public class CashPayment implements PaymentStrategy {

    @Override
    public void pay(double amount) {
        System.out.printf("  [Cash] Customer pays $%.2f in cash.%n", amount);
    }
}
