package com.coffeeshop.behavioral.strategy;

/**
 * Concrete strategy that processes payment via credit card.
 * <p>
 * Masks the card number for security before printing transaction details.
 */
public class CreditCardPayment implements PaymentStrategy {

    private final String cardNumber;
    private final String cardHolderName;

    public CreditCardPayment(String cardNumber, String cardHolderName) {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
    }

    @Override
    public void pay(double amount) {
        System.out.printf("  [CreditCard] Charged $%.2f from %s (card: %s)%n",
                amount, cardHolderName, maskCard(cardNumber));
    }

    private static String maskCard(String card) {
        return "****-****-****-" + card.substring(card.length() - 4);
    }
}
