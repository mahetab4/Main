package com.coffeeshop.behavioral.strategy;

/**
 * Concrete strategy that processes payment via a mobile digital wallet.
 * <p>
 * Charges the amount to the wallet identified by {@code walletId}.
 */
public class MobileWalletPayment implements PaymentStrategy {

    private final String walletId;

    public MobileWalletPayment(String walletId) {
        this.walletId = walletId;
    }

    @Override
    public void pay(double amount) {
        System.out.printf("  [MobileWallet] Charged $%.2f from wallet %s%n",
                amount, walletId);
    }
}
