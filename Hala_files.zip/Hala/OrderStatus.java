package com.coffeeshop.behavioral.observer;

/** Order lifecycle states — used by Observer pattern. */
public enum OrderStatus {
    PLACED, PREPARING, READY, SERVED, CANCELLED
}
