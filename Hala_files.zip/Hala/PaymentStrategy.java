package com.coffeeshop.behavioral.strategy;

/**
 * Strategy interface for payment processing.
 * <p>
 * <strong>Pattern:</strong> Strategy (GoF)<br>
 * <strong>Intent:</strong> Define a family of algorithms, encapsulate each one,
 * and make them interchangeable. Strategy lets the algorithm vary independently
 * from the clients that use it.
 * <p>
 * Concrete implementations:
 * <ul>
 *   <li>{@link CreditCardPayment} — charges a credit card</li>
 *   <li>{@link CashPayment} — records cash tendered</li>
 *   <li>{@link MobileWalletPayment} — charges a digital wallet</li>
 * </ul>
 * Clients (e.g., {@link com.coffeeshop.behavioral.command.PlaceOrderCommand})
 * accept any {@code PaymentStrategy}, enabling runtime payment method switching
 * without conditional logic.
 */
@FunctionalInterface
public interface PaymentStrategy {

    /**
     * Processes a payment for the given amount.
     *
     * @param amount the monetary amount to charge
     */
    void pay(double amount);
}
