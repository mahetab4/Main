package com.coffeeshop;

import com.coffeeshop.behavioral.command.OrderInvoker;
import com.coffeeshop.behavioral.command.PlaceOrderCommand;
import com.coffeeshop.behavioral.observer.*;
import com.coffeeshop.behavioral.strategy.*;
import com.coffeeshop.creational.builder.OrderBuilder;
import com.coffeeshop.creational.factory.BeverageFactory;
import com.coffeeshop.creational.factory.BeverageType;
import com.coffeeshop.creational.singleton.ShopManager;
import com.coffeeshop.structural.adapter.ExternalPaymentGateway;
import com.coffeeshop.structural.adapter.PaymentAdapter;
import com.coffeeshop.structural.decorator.Beverage;

public class App {

    private static void printSeparator(char ch, int len) {
        System.out.println(String.valueOf(ch).repeat(len));
    }

    private static void printHeader(String title) {
        printSeparator('=', 55);
        System.out.println("  " + title);
        printSeparator('=', 55);
    }

    private static void printSubHeader(String title) {
        printSeparator('-', 40);
        System.out.println("  " + title);
        printSeparator('-', 40);
    }

    public static void main(String[] args) {
        printHeader(" DESIGN PATTERNS COFFEE SHOP ");
        System.out.println("  Welcome! This demo shows 8 design patterns working together.");
        System.out.println("  3 orders will be processed with different lifecycles.\n");

        // ===== SINGLETON =====
        printSubHeader(" PATTERN: Singleton ");
        System.out.println("  ShopManager.getInstance() returns the single global instance.\n");

        ShopManager shop = ShopManager.getInstance();
        shop.displayInfo();
        System.out.println();

        // ===== FACTORY METHOD + BUILDER + DECORATOR =====
        printSubHeader(" PATTERNS: Factory Method + Builder + Decorator ");
        System.out.println("  Creating beverages using Factory Method...\n");

        Beverage espresso = BeverageFactory.createBeverage(BeverageType.ESPRESSO);
        Beverage latte    = BeverageFactory.createBeverage(BeverageType.LATTE);

        System.out.println("  Base drinks created:");
        System.out.println("    " + espresso.getDescriptionWithCost());
        System.out.println("    " + latte.getDescriptionWithCost());

        System.out.println("\n  Order #2 will be customized using Builder + Decorator:\n");
        Beverage customOrder = new OrderBuilder()
                .selectBeverage(latte)
                .addMilk()
                .addSugar()
                .addWhippedCream()
                .addExtraShot(2)
                .addNote("Extra hot please!")
                .build();

        System.out.println("  Custom order built:");
        System.out.println("    " + customOrder.getDescriptionWithCost());
        System.out.println();

        Beverage hotChoc = BeverageFactory.createBeverage(BeverageType.HOT_CHOCOLATE);
        System.out.println("  Order #3 base drink:");
        System.out.println("    " + hotChoc.getDescriptionWithCost());
        System.out.println();

        // ===== STRATEGY =====
        printSubHeader(" PATTERN: Strategy ");
        System.out.println("  Creating different payment strategies...\n");

        PaymentStrategy creditCard = new CreditCardPayment("1234567890123456", "John Doe");
        PaymentStrategy wallet     = new MobileWalletPayment("alice_wallet_001");
        System.out.println("  - CreditCardPayment for John Doe");
        System.out.println("  - MobileWalletPayment for wallet alice_wallet_001\n");

        // ===== ADAPTER =====
        printSubHeader(" PATTERN: Adapter ");
        System.out.println("  Wrapping ExternalPaymentGateway as a PaymentStrategy...\n");
        ExternalPaymentGateway gateway = new ExternalPaymentGateway();
        PaymentStrategy adaptedPayment = new PaymentAdapter(gateway, "9876543210987654");
        System.out.println("  ExternalPaymentGateway adapted to PaymentStrategy interface.\n");

        // ===== OBSERVER =====
        printSubHeader(" PATTERN: Observer ");
        System.out.println("  Creating order subjects and attaching observers...\n");

        int orderNum = shop.getNextOrderNumber();
        OrderSubject order1 = new OrderSubject(orderNum);
        order1.attach(new CustomerNotifier("Alice"));
        order1.attach(new BaristaDisplay("Bob"));
        System.out.println("  Order #" + orderNum + ": Alice (customer) + Bob (barista) watching");

        OrderSubject order2 = new OrderSubject(shop.getNextOrderNumber());
        order2.attach(new CustomerNotifier("Charlie"));
        order2.attach(new BaristaDisplay("Diana"));
        System.out.println("  Order #" + order2.getOrderNumber() + ": Charlie (customer) + Diana (barista) watching");

        OrderSubject order3 = new OrderSubject(shop.getNextOrderNumber());
        order3.attach(new CustomerNotifier("Eve"));
        order3.attach(new BaristaDisplay("Frank"));
        System.out.println("  Order #" + order3.getOrderNumber() + ": Eve (customer) + Frank (barista) watching");

        System.out.println();

        // ===== COMMAND =====
        printSubHeader(" PATTERN: Command ");
        System.out.println("  Queueing 3 orders as Command objects in OrderInvoker...\n");

        OrderInvoker invoker = new OrderInvoker();

        invoker.placeCommand(new PlaceOrderCommand(espresso, creditCard, order1));
        System.out.println("  [Queued] Order #" + order1.getOrderNumber() + " Espresso - CreditCard");

        invoker.placeCommand(new PlaceOrderCommand(customOrder, wallet, order2));
        System.out.println("  [Queued] Order #" + order2.getOrderNumber() + " Custom Latte - MobileWallet");

        invoker.placeCommand(new PlaceOrderCommand(hotChoc, adaptedPayment, order3));
        System.out.println("  [Queued] Order #" + order3.getOrderNumber() + " Hot Chocolate - Adapter");

        System.out.println("\n  Total commands in queue: " + invoker.pendingCount());

        // ===== EXECUTION =====
        printSeparator('=', 55);
        System.out.println("  STEP 1: PROCESSING ALL ORDERS");
        System.out.println("  (invoker.processAll() dequeues & executes commands)");
        printSeparator('=', 55);
        System.out.println();
        invoker.processAll();

        System.out.println();

        // ===== ORDER 1: DONE (READY + SERVED) =====
        printSeparator('=', 55);
        System.out.println("  ORDER #" + order1.getOrderNumber() + " - ESPRESSO (completed)");
        System.out.println("  Customer: Alice  |  Barista: Bob");
        printSeparator('=', 55);
        System.out.println();

        System.out.println("  --- Status: PLACED -> PREPARING (done by command) ---\n");

        System.out.println("  >>> Barista finishes making the Espresso...\n");
        order1.setStatus(OrderStatus.READY);

        System.out.println("\n  >>> Alice picks up her Espresso...\n");
        order1.setStatus(OrderStatus.SERVED);

        System.out.println();
        printSeparator('=', 55);
        System.out.println("  RESULT: Order #" + order1.getOrderNumber() + " is COMPLETED SUCCESSFULLY");
        printSeparator('=', 55);
        System.out.println();

        // ===== ORDER 2: DONE (READY + SERVED) =====
        printSeparator('=', 55);
        System.out.println("  ORDER #" + order2.getOrderNumber() + " - CUSTOM LATTE (completed)");
        System.out.println("  Customer: Charlie  |  Barista: Diana");
        printSeparator('=', 55);
        System.out.println();

        System.out.println("  --- Status: PLACED -> PREPARING (done by command) ---\n");

        System.out.println("  >>> Diana finishes the Custom Latte...\n");
        order2.setStatus(OrderStatus.READY);

        System.out.println("\n  >>> Charlie picks up his Custom Latte...\n");
        order2.setStatus(OrderStatus.SERVED);

        System.out.println();
        printSeparator('=', 55);
        System.out.println("  RESULT: Order #" + order2.getOrderNumber() + " is COMPLETED SUCCESSFULLY");
        printSeparator('=', 55);
        System.out.println();

        // ===== ORDER 3: CANCELLED =====
        printSeparator('=', 55);
        System.out.println("  ORDER #" + order3.getOrderNumber() + " - HOT CHOCOLATE (cancelled)");
        System.out.println("  Customer: Eve  |  Barista: Frank");
        printSeparator('=', 55);
        System.out.println();

        System.out.println("  --- Status: PLACED -> PREPARING (done by command) ---\n");

        System.out.println("  >>> Oh no! Eve decides to cancel her order...\n");
        order3.setStatus(OrderStatus.CANCELLED);

        System.out.println();
        printSeparator('=', 55);
        System.out.println("  RESULT: Order #" + order3.getOrderNumber() + " was CANCELLED");
        printSeparator('=', 55);
        System.out.println();

        // ===== SUMMARY =====
        printHeader(" FINAL SUMMARY ");
        int total = shop.getNextOrderNumber() - 1001;
        System.out.println("  Total orders created: " + total);
        System.out.println("  Orders completed:     2 (Orders #" + order1.getOrderNumber()
                + ", #" + order2.getOrderNumber() + ")");
        System.out.println("  Orders cancelled:     1 (Order #" + order3.getOrderNumber() + ")");
        System.out.println("\n  Patterns demonstrated:");
        System.out.println("    Creational : Singleton, Factory Method, Builder");
        System.out.println("    Structural : Decorator, Adapter");
        System.out.println("    Behavioral : Strategy, Observer, Command");
        printSeparator('=', 55);
        System.out.println("  DEMO COMPLETE - All 8 design patterns executed.");
        printSeparator('=', 55);
    }
}
