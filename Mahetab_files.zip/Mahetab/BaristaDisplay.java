package com.coffeeshop.behavioral.observer;

public class BaristaDisplay implements OrderObserver {

    private final String baristaName;

    public BaristaDisplay(String baristaName) {
        this.baristaName = baristaName;
    }

    @Override
    public void update(int orderNumber, OrderStatus status) {
        switch (status) {
            case PLACED ->
                System.out.printf("  [Barista %s] New order #%d received! Let me start making it...%n",
                        baristaName, orderNumber);
            case PREPARING ->
                System.out.printf("  [Barista %s] Working on order #%d... almost done!%n",
                        baristaName, orderNumber);
            case READY ->
                System.out.printf("  [Barista %s] Order #%d is ready! Calling customer to pick up...%n",
                        baristaName, orderNumber);
            case SERVED ->
                System.out.printf("  [Barista %s] Order #%d served. Moving to next order.%n",
                        baristaName, orderNumber);
            case CANCELLED ->
                System.out.printf("  [Barista %s] Order #%d was cancelled. Stopping preparation.%n",
                        baristaName, orderNumber);
        }
    }
}
