package com.coffeeshop.behavioral.observer;

public class CustomerNotifier implements OrderObserver {

    private final String customerName;

    public CustomerNotifier(String customerName) {
        this.customerName = customerName;
    }

    @Override
    public void update(int orderNumber, OrderStatus status) {
        switch (status) {
            case PLACED ->
                System.out.printf("  [Notify %s] Your order #%d has been received!%n",
                        customerName, orderNumber);
            case PREPARING ->
                System.out.printf("  [Notify %s] Your order #%d is being prepared!%n",
                        customerName, orderNumber);
            case READY ->
                System.out.printf("  [Notify %s] Your order #%d is READY for pickup!%n",
                        customerName, orderNumber);
            case SERVED ->
                System.out.printf("  [Notify %s] Thank you! Order #%d has been served. Enjoy!%n",
                        customerName, orderNumber);
            case CANCELLED ->
                System.out.printf("  [Notify %s] Order #%d has been CANCELLED.%n",
                        customerName, orderNumber);
        }
    }
}
