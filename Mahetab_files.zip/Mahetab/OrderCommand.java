package com.coffeeshop.behavioral.command;

/** Command interface — Command pattern (GoF). */
public interface OrderCommand {
    void execute();
}
