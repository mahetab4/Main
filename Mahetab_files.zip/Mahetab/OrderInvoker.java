package com.coffeeshop.behavioral.command;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Invoker that queues and executes {@link OrderCommand} objects.
 * <p>
 * <strong>Pattern:</strong> Command (GoF) — Invoker role<br>
 * <strong>Intent:</strong> Encapsulate a request as an object, thereby letting
 * you queue or log requests.
 * <p>
 * Commands are processed in FIFO order. The invoker is completely decoupled
 * from the command implementations \u2014 it only knows the {@code OrderCommand}
 * interface. New command types can be added without changing the invoker.
 */
public class OrderInvoker {

    private final Queue<OrderCommand> commandQueue;

    public OrderInvoker() {
        this.commandQueue = new LinkedList<>();
    }

    /** Adds a command to the end of the processing queue. */
    public void placeCommand(OrderCommand command) {
        commandQueue.add(command);
    }

    /** Dequeues and executes the next pending command, if any. */
    public void processNext() {
        OrderCommand command = commandQueue.poll();
        if (command != null) {
            command.execute();
        } else {
            System.out.println("  [Invoker] No pending commands.");
        }
    }

    /** Processes all remaining commands in the queue sequentially. */
    public void processAll() {
        while (!commandQueue.isEmpty()) {
            processNext();
        }
    }

    /** Returns the number of commands currently waiting in the queue. */
    public int pendingCount() {
        return commandQueue.size();
    }
}
