package com.coffeeshop.behavioral.observer;

/**
 * Observer interface for receiving order status change notifications.
 * <p>
 * <strong>Pattern:</strong> Observer (GoF) — Observer role<br>
 * <strong>Intent:</strong> Define a one-to-many dependency between objects so
 * that when one object changes state, all its dependents are notified and
 * updated automatically.
 * <p>
 * Implementations:
 * <ul>
 *   <li>{@link CustomerNotifier} — sends status updates to customers</li>
 *   <li>{@link BaristaDisplay} — alerts baristas of new orders</li>
 * </ul>
 *
 * @see OrderSubject
 */
@FunctionalInterface
public interface OrderObserver {

    /**
     * Invoked when the observed order changes status.
     *
     * @param orderNumber the order that changed
     * @param status      the new status
     */
    void update(int orderNumber, OrderStatus status);
}
