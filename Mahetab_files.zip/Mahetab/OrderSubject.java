package com.coffeeshop.behavioral.observer;

import java.util.ArrayList;
import java.util.List;

/**
 * Observable subject that tracks an order's status and notifies all attached
 * observers on every state change.
 * <p>
 * <strong>Pattern:</strong> Observer (GoF) — Subject role<br>
 * <strong>Intent:</strong> Define a one-to-many dependency between objects so
 * that when one object changes state, all its dependents are notified.
 * <p>
 * Observers are completely decoupled from the subject; new observer types can
 * be added without modifying this class.
 */
public class OrderSubject {

    private final List<OrderObserver> observers;
    private final int orderNumber;
    private OrderStatus status;

    public OrderSubject(int orderNumber) {
        this.observers = new ArrayList<>();
        this.orderNumber = orderNumber;
        this.status = OrderStatus.PLACED;
    }

    /** Registers an observer to receive status updates. */
    public void attach(OrderObserver observer) {
        observers.add(observer);
    }

    /** Unregisters an observer so it no longer receives updates. */
    public void detach(OrderObserver observer) {
        observers.remove(observer);
    }

    /**
     * Updates the order status and notifies all registered observers.
     *
     * @param status the new order status
     */
    public void setStatus(OrderStatus status) {
        this.status = status;
        notifyAllObservers();
    }

    private void notifyAllObservers() {
        for (OrderObserver observer : observers) {
            observer.update(orderNumber, status);
        }
    }

    public int getOrderNumber() {
        return orderNumber;
    }

    public OrderStatus getStatus() {
        return status;
    }
}
