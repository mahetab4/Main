package com.coffeeshop.behavioral.command;

import com.coffeeshop.behavioral.observer.OrderStatus;
import com.coffeeshop.behavioral.observer.OrderSubject;
import com.coffeeshop.behavioral.strategy.PaymentStrategy;
import com.coffeeshop.structural.decorator.Beverage;

public class PlaceOrderCommand implements OrderCommand {

    private final Beverage beverage;
    private final PaymentStrategy paymentStrategy;
    private final OrderSubject orderSubject;

    public PlaceOrderCommand(Beverage beverage, PaymentStrategy paymentStrategy, OrderSubject orderSubject) {
        this.beverage = beverage;
        this.paymentStrategy = paymentStrategy;
        this.orderSubject = orderSubject;
    }

    @Override
    public void execute() {
        double total = beverage.cost();
        System.out.println("  +--> [Command] Processing Order #" + orderSubject.getOrderNumber());
        System.out.println("  |    Item : " + beverage.getDescription());
        System.out.println("  |    Price: $" + String.format("%.2f", total));
        System.out.println("  |    Processing payment...");
        paymentStrategy.pay(total);
        System.out.println("  |    Order #" + orderSubject.getOrderNumber() + " is now being prepared...");
        orderSubject.setStatus(OrderStatus.PREPARING);
        System.out.println("  +--> Done");
        System.out.println();
    }
}
